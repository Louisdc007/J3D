import pygame
import sys
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
FRIEND_SRC = os.path.join(BASE_DIR, "sourceCode", "src")

if FRIEND_SRC not in sys.path:
    sys.path.append(FRIEND_SRC)

try:
    # On importe aussi TILE_SIZE de Louis
    from settings import WIDTH, HEIGHT, FPS, TILE_SIZE
    SCREEN_WIDTH = WIDTH
    SCREEN_HEIGHT = HEIGHT
    print(f"DEBUG Constants: Tailles récupérées ({WIDTH}x{HEIGHT})")
except ImportError:
    SCREEN_WIDTH = 1280
    SCREEN_HEIGHT = 720
    FPS = 60
    TILE_SIZE = 64
    print("DEBUG Constants: Import échoué, utilisation des valeurs par défaut")

# --- CORRECTION DE LA LIMITE DU MONDE ---
# Le donjon de Louis fait 100x100 tuiles. On donne cette taille exacte au serveur.
WORLD_WIDTH = 6400  # = 6400 pixels
WORLD_HEIGHT = 6400 # = 6400 pixels
# ----------------------------------------

GRAY = (128, 128, 128)
ORANGE = (255, 165, 0)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)

PLAYER_SIZE = 40
PLAYER_HEIGHT_MULT = 3
PLAYER_SPEED = 4
PLAYER_MAX_HEALTH = 20
ROLL_SPEED = 12
ROLL_DURATION_FRAMES = 15
RECOIL_INITIAL_FORCE = 8
RECOIL_DRAG = 0.85
STUN_DURATION = 30
INVINCIBILITY_DURATION = 30
NUM_OBSTACLES = 50
