# -*- mode: python ; coding: utf-8 -*-
# Fichier de configuration PyInstaller pour "Greed"
# Génère un dossier dist/Greed/ avec l'exécutable et tous les assets nécessaires.

import os
import sys

# Chemin racine du code source
src_path = os.path.abspath(os.path.join(SPECPATH, 'src'))

# -----------------------------------------------------------------------
# Données (assets) à embarquer dans le build
# Format : (source, destination_dans_le_build)
# -----------------------------------------------------------------------
datas = [
    # Assets graphiques et audio
    (os.path.join(src_path, 'assets'), 'assets'),
    # Module multijoueur (inclus en tant que package)
    (os.path.join(src_path, 'systeme_multijoueur'), 'systeme_multijoueur'),
]

# -----------------------------------------------------------------------
# Modules cachés (imports dynamiques que PyInstaller ne détecte pas seul)
# -----------------------------------------------------------------------
hiddenimports = [
    'pygame',
    'pygame.mixer',
    'pygame.font',
    'pygame.image',
    'pygame.transform',
    'threading',
    'json',
    'socket',
    'pickle',
    'network',
    'game_server',
]

a = Analysis(
    [os.path.join(src_path, 'main.py')],
    pathex=[src_path, os.path.join(src_path, 'systeme_multijoueur')],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        'pyautogui',     # Retiré du projet
        'tkinter',
        'matplotlib',
        'numpy',
        'scipy',
        'PIL',
    ],
    noarchive=False,
    optimize=0,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,                  # Mode "one-file" : tout dans un seul .exe
    a.datas,
    [],
    exclude_binaries=False,      # Tout est embarqué dans le .exe
    name='Greed',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,                    # Compression UPX pour réduire la taille
    console=False,               # Pas de fenêtre console (version finale)
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    uac_admin=True,              # Demande les droits admin au lancement (popup UAC Windows)
                                 # → permet d'ajouter la règle pare-feu automatiquement
    # icon='src/assets/icon.ico',
)
# Pas de COLLECT en mode one-file — tout est dans dist/Greed.exe
